#!/system/bin/sh
M=$(cd "$(dirname "$0")" && pwd)
FOLD_MS=6333   # part0 of the shutdown animation
LOAD_MS=400         # bootanimation opening the zip before the first frame
HOLD_MS=300         # the ember sits for a moment before the screen goes
say() { log -t VoidOS "screenoff: $*" 2>/dev/null; }
command -v getprop >/dev/null 2>&1 || exit 0
[ -n "$(getprop sys.shutdown.requested)" ] || { say "no shutdown in progress"; exit 0; }
now_ms() { read -r up _ < /proc/uptime; s=${up%.*}; f=${up#*.}; f=${f#0}; echo $(( s * 1000 + ${f:-0} * 10 )); }
pid=""
i=0
while [ $i -lt 30 ]; do
  # AOSP's bootanimation, or MediaTek's mtkbootanimation (banim_shut*)
  pid=$(pidof bootanimation 2>/dev/null)
  [ -n "$pid" ] || pid=$(pidof mtkbootanimation 2>/dev/null)
  [ -n "$pid" ] && break
  sleep 0.1
  i=$((i + 1))
done
[ -n "$pid" ] || { say "no shutdown animation playing"; exit 0; }
set -- $pid; pid=$1
read -r st < /proc/$pid/stat || exit 0
set -- $st; shift 21; start_ms=$(( $1 * 10 ))   # starttime, in 1/100 s
off=$(cat "$M/screenoff.offset" 2>/dev/null); case "$off" in ''|*[!0-9-]*) off=0 ;; esac
wait_ms=$(( start_ms + LOAD_MS + FOLD_MS + HOLD_MS + off - $(now_ms) ))
[ $wait_ms -gt 20000 ] && wait_ms=20000
[ $wait_ms -gt 0 ] && sleep $(( wait_ms / 1000 )).$(printf %03d $(( wait_ms % 1000 )))
[ -d /proc/$pid ] || { say "animation already gone"; exit 0; }
bl=""
for f in $VOID_TEST_BL /sys/class/leds/lcd-backlight/brightness /sys/class/backlight/*/brightness; do
  [ -w "$f" ] && { bl=$f; break; }
done
[ -n "$bl" ] || { say "no backlight control found"; exit 0; }
cur=$(cat "$bl" 2>/dev/null); case "$cur" in ''|*[!0-9]*) cur=0 ;; esac
n=5
while [ $n -gt 0 ] && [ $cur -gt 0 ]; do
  n=$((n - 1))
  echo $(( cur * n / 6 )) > "$bl"
  sleep 0.05
done
echo 0 > "$bl"
say "backlight off after the fold ($bl)"
exit 0
