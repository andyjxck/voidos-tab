#!/system/bin/sh
# usage: orient.sh 0|90|270 [boot]
M=$(cd "$(dirname "$0")" && pwd)
R=$1
case "$R" in 0|90|270) ;; *) R=0 ;; esac
S=$M/orient/$R
[ -f "$S/bootanimation.zip" ] || exit 3
put() { # put <name> <version file> <target>...
  name=$1; mark=$2; shift 2
  [ "$(cat "$mark" 2>/dev/null)" = "$R" ] && return 0
  for t in "$@"; do
    [ -f "$t" ] || continue
    cat "$S/$name" > "$t" || return 1
  done
  sync
  echo "$R" > "$mark"
}
BOOT="$M/system/media/bootanimation.zip $M/system/product/media/bootanimation.zip"
if [ "$2" = boot ]; then
  # at shutdown: first start screenoff.sh on its own (so the picture goes
  # out with the screen), then only the boot animation, as the shutdown one
  # is playing
  if [ -f "$M/screenoff.sh" ]; then
    if command -v setsid >/dev/null 2>&1; then
      ( setsid sh "$M/screenoff.sh" </dev/null >/dev/null 2>&1 & )
    else
      ( sh "$M/screenoff.sh" </dev/null >/dev/null 2>&1 & )
    fi
  fi
  put bootanimation.zip $M/orient/boot.now $BOOT || exit 1
  exit 0
fi
# never under an animation that is playing (VoidOS tries again later)
[ "$(getprop init.svc.bootanim)" = running ] && exit 4
put bootanimation.zip $M/orient/boot.now $BOOT || exit 1
put shutdownanimation.zip $M/orient/shutdown.now $M/system/media/shutdownanimation.zip || exit 1
exit 0
