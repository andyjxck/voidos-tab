# Runs inside Magisk's installer.
ui_print "- VoidOS boot animation"
ui_print "- Reboot to see it. Remove this module in Magisk to undo."
set_perm_recursive $MODPATH/system 0 0 0755 0644
