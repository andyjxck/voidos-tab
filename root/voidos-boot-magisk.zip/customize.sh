# Runs inside Magisk's installer.
ui_print "- VoidOS boot and shutdown animation"
ui_print "- Reboot to see it. Remove this module in Magisk to undo."
# the boot animation is shipped once and copied here, so the module stays
# small: Android 10 plays /product/media's copy first when there is one, and
# the TB-X306F has one
mkdir -p $MODPATH/system/product/media
cp -f $MODPATH/system/media/bootanimation.zip $MODPATH/system/product/media/bootanimation.zip
# the portrait pair is also the one orient.sh puts back for rotation 0
mkdir -p $MODPATH/orient/0
cp -f $MODPATH/system/media/bootanimation.zip $MODPATH/orient/0/bootanimation.zip
cp -f $MODPATH/system/media/shutdownanimation.zip $MODPATH/orient/0/shutdownanimation.zip
echo 0 > $MODPATH/orient/boot.now
echo 0 > $MODPATH/orient/shutdown.now
set_perm_recursive $MODPATH/system 0 0 0755 0644
set_perm_recursive $MODPATH/orient 0 0 0755 0644
set_perm $MODPATH/orient.sh 0 0 0755
