# Runs inside Magisk's installer.
ui_print "- VoidOS boot and shutdown animation"
ui_print "- Reboot to see it. Remove this module in Magisk to undo."
# the boot animation is shipped once and copied here, so the module stays
# small enough to send in a chat: Android 10 plays /product/media's copy first
# when there is one, and the TB-X306F has one
mkdir -p $MODPATH/system/product/media
cp -f $MODPATH/system/media/bootanimation.zip $MODPATH/system/product/media/bootanimation.zip
set_perm_recursive $MODPATH/system 0 0 0755 0644
