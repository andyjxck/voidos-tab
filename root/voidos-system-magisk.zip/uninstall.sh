#!/system/bin/sh
(
  until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 2; done
  settings put global power_button_long_press 1
  case "$(settings get secure assistant)" in *com.andysocial.voidos*) settings delete secure assistant ;; esac
) &
