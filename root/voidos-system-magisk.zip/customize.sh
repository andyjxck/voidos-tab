# Runs inside Magisk's installer.
ui_print "- VoidOS system app"
API=$(getprop ro.build.version.sdk)
MODEL=$(getprop ro.product.model)
ui_print "- Device: $MODEL, Android API $API"
if [ "$API" -lt 29 ]; then
  abort "! VoidOS needs Android 10 (API 29) or newer"
fi
case "$MODEL" in
  *X306F*) ;;
  *) ui_print "! Not a TB-X306F: VoidOS was built for that tablet. Continuing anyway." ;;
esac
ui_print "- privapp enforcement: $(getprop ro.control_privapp_permissions)"
# keep only the native library folder for this tablet's ABI
ABI=$(getprop ro.product.cpu.abi)
case "$ABI" in
  arm64*) rm -rf $MODPATH/system/priv-app/VoidOS/lib/arm ;;
  *) rm -rf $MODPATH/system/priv-app/VoidOS/lib/arm64 ;;
esac
ui_print "- Reboot. If VoidOS is already installed with the same key it stays,"
ui_print "  now as an updated system app. Remove this module in Magisk to undo."
set_perm_recursive $MODPATH/system 0 0 0755 0644
set_perm $MODPATH/service.sh 0 0 0755
ui_print "- No navigation bar from the next boot (hold volume down while booting"
ui_print "  for Magisk safe mode if you ever need Android's bar back)."
