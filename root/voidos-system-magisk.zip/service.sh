#!/system/bin/sh
# VoidOS system app: runs late in every boot.
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 2; done
sleep 4
P=com.andysocial.voidos
resetprop qemu.hw.mainkeys 1 2>/dev/null
settings put global policy_control 'immersive.full=*:immersive.preconfirms=*'
appops set $P SYSTEM_ALERT_WINDOW allow
pm grant $P android.permission.WRITE_SECURE_SETTINGS 2>/dev/null
# 1.19: VoidOS's own permissions granted up front, so Android's "Allow VoidOS to..." prompts never show
for perm in ACCESS_FINE_LOCATION ACCESS_COARSE_LOCATION CAMERA RECORD_AUDIO READ_CALENDAR READ_EXTERNAL_STORAGE WRITE_EXTERNAL_STORAGE; do
  pm grant $P android.permission.$perm 2>/dev/null
done
appops set $P WRITE_SETTINGS allow 2>/dev/null
appops set $P ACCESS_NOTIFICATIONS allow 2>/dev/null
cmd notification allow_listener $P/$P.VoidListener 2>/dev/null
cmd notification allow_dnd $P 2>/dev/null
# VoidOS's volume sliders, power menu and PIN pad (an accessibility service)
S=$P/$P.VoidKeysService
CUR=$(settings get secure enabled_accessibility_services)
case "$CUR" in
  *VoidKeysService*) ;;
  null|"") settings put secure enabled_accessibility_services $S ;;
  *) settings put secure enabled_accessibility_services "$CUR:$S" ;;
esac
settings put secure accessibility_enabled 1
# no "Viewing full screen" or accessibility shortcut dialogs
settings put secure accessibility_shortcut_dialog_shown 1
settings put secure immersive_mode_confirmations confirmed
